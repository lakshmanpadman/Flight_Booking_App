﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightBookingApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if(Form1.Passport)
            {
                lblChangeDocument.Text = "Passport No:";
                lblChangeExpiryDate.Text = "Passport Expiry Date:";
            }
            if(Form1.IDCard)
            {
                lblChangeDocument.Text = "ID Card No:";
                lblChangeExpiryDate.Text = "ID Card Expiry Date:";
            }

            lblFullName.Text = Form1.firstName + "  " + Form1.LastName;
            lblDepartureCity.Text = Form1.From;
            lblDestination.Text = Form1.To;
            lblDepartureCity.Text = Form1.From;
            lbltripDates.Text = Form1.StartTripDate + "  to  " + Form1.EndTripDate;
            lblDocumentNo.Text = Form1.DocumentNo;
            lblExpiryDate.Text = Form1.ExpiryDate;
            lblBaggageWeight.Text = Form1.WeightBaggage;
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
