﻿namespace FlightBookingApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblDepartureCity = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDestination = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbltripDates = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblDocumentNo = new System.Windows.Forms.Label();
            this.lblChangeDocument = new System.Windows.Forms.Label();
            this.lblExpiryDate = new System.Windows.Forms.Label();
            this.lblChangeExpiryDate = new System.Windows.Forms.Label();
            this.lblBaggageWeight = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(609, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Congradulations, you have booked a ticket. Please check mail and Confirm.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(77, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = " Full Name:";
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullName.Location = new System.Drawing.Point(268, 74);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(99, 20);
            this.lblFullName.TabIndex = 3;
            this.lblFullName.Text = " Full Name:";
            // 
            // lblDepartureCity
            // 
            this.lblDepartureCity.AutoSize = true;
            this.lblDepartureCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartureCity.Location = new System.Drawing.Point(268, 127);
            this.lblDepartureCity.Name = "lblDepartureCity";
            this.lblDepartureCity.Size = new System.Drawing.Size(99, 20);
            this.lblDepartureCity.TabIndex = 5;
            this.lblDepartureCity.Text = " Full Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(77, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = " Departure City:";
            // 
            // lblDestination
            // 
            this.lblDestination.AutoSize = true;
            this.lblDestination.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestination.Location = new System.Drawing.Point(274, 182);
            this.lblDestination.Name = "lblDestination";
            this.lblDestination.Size = new System.Drawing.Size(99, 20);
            this.lblDestination.TabIndex = 7;
            this.lblDestination.Text = " Full Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(83, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Destination City:";
            // 
            // lbltripDates
            // 
            this.lbltripDates.AutoSize = true;
            this.lbltripDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltripDates.Location = new System.Drawing.Point(274, 246);
            this.lbltripDates.Name = "lbltripDates";
            this.lbltripDates.Size = new System.Drawing.Size(99, 20);
            this.lbltripDates.TabIndex = 9;
            this.lbltripDates.Text = " Full Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(83, 246);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "trip Dates:";
            // 
            // lblDocumentNo
            // 
            this.lblDocumentNo.AutoSize = true;
            this.lblDocumentNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDocumentNo.Location = new System.Drawing.Point(275, 310);
            this.lblDocumentNo.Name = "lblDocumentNo";
            this.lblDocumentNo.Size = new System.Drawing.Size(99, 20);
            this.lblDocumentNo.TabIndex = 11;
            this.lblDocumentNo.Text = " Full Name:";
            // 
            // lblChangeDocument
            // 
            this.lblChangeDocument.AutoSize = true;
            this.lblChangeDocument.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeDocument.Location = new System.Drawing.Point(81, 310);
            this.lblChangeDocument.Name = "lblChangeDocument";
            this.lblChangeDocument.Size = new System.Drawing.Size(123, 20);
            this.lblChangeDocument.TabIndex = 10;
            this.lblChangeDocument.Text = "Document No:";
            // 
            // lblExpiryDate
            // 
            this.lblExpiryDate.AutoSize = true;
            this.lblExpiryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpiryDate.Location = new System.Drawing.Point(276, 368);
            this.lblExpiryDate.Name = "lblExpiryDate";
            this.lblExpiryDate.Size = new System.Drawing.Size(99, 20);
            this.lblExpiryDate.TabIndex = 13;
            this.lblExpiryDate.Text = " Full Name:";
            // 
            // lblChangeExpiryDate
            // 
            this.lblChangeExpiryDate.AutoSize = true;
            this.lblChangeExpiryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeExpiryDate.Location = new System.Drawing.Point(72, 368);
            this.lblChangeExpiryDate.Name = "lblChangeExpiryDate";
            this.lblChangeExpiryDate.Size = new System.Drawing.Size(198, 20);
            this.lblChangeExpiryDate.TabIndex = 12;
            this.lblChangeExpiryDate.Text = " Document Expiry Date:";
            // 
            // lblBaggageWeight
            // 
            this.lblBaggageWeight.AutoSize = true;
            this.lblBaggageWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaggageWeight.Location = new System.Drawing.Point(277, 434);
            this.lblBaggageWeight.Name = "lblBaggageWeight";
            this.lblBaggageWeight.Size = new System.Drawing.Size(99, 20);
            this.lblBaggageWeight.TabIndex = 15;
            this.lblBaggageWeight.Text = " Full Name:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(73, 434);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Baggage Weight:";
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.Color.Orange;
            this.btnDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.Location = new System.Drawing.Point(0, 475);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(801, 35);
            this.btnDone.TabIndex = 16;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 510);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.lblBaggageWeight);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lblExpiryDate);
            this.Controls.Add(this.lblChangeExpiryDate);
            this.Controls.Add(this.lblDocumentNo);
            this.Controls.Add(this.lblChangeDocument);
            this.Controls.Add(this.lbltripDates);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblDestination);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblDepartureCity);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Booking Summary";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblDepartureCity;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblDestination;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbltripDates;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblDocumentNo;
        private System.Windows.Forms.Label lblChangeDocument;
        private System.Windows.Forms.Label lblExpiryDate;
        private System.Windows.Forms.Label lblChangeExpiryDate;
        private System.Windows.Forms.Label lblBaggageWeight;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnDone;
    }
}